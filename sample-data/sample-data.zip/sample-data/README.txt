Sample Data for 3D Data Visualization Project.

------------------------------------------------

* Data for Regional template
-----------------
Regonal/PR-by-country.csv ( Immigration data from the resource. http://open.canada.ca/data/en/dataset/40fe637b-c7e7-4454-88b5-78530f220cba )


* Data for Location template
-----------------
Location/test.csv ( Test data for location template. )
Location/earthquake2.5month.csv ( Earth quake data from the resource. http://earthquake.usgs.gov/earthquakes/feed/v1.0/csv.php )


* Data for Realtime template
-----------------
Realtime/earthquake2.5month.csv ( Earth quake data from the resource. http://earthquake.usgs.gov/earthquakes/feed/v1.0/csv.php )


* Data for Relationship template
-----------------
Relationship/flight-from-jfk.csv ( Flight data from the resource. http://openflights.org/data.html#license )


* Data for Pointcloud template
-----------------
Pointcloud/curreny-against-usd.csv ( Currency data against USD )


------------------------------------------------
